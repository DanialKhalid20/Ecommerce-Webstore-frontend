import Carousel from 'react-bootstrap/Carousel';
import './navbar.css'

function UncontrolledExample() {
  return (
    <Carousel >
      <Carousel.Item>
        <img
          className="carousal"
         
          src="vivo-y01-featured_2_728x438.jpg"
          alt="First slide"
        />
        {/* <Carousel.Caption>
          <h3>First slide label</h3>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption> */}
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="carousal2"
          src="016_728x438.jpg"
          alt="Second slide"
        />

        {/* <Carousel.Caption>
          <h3>Second slide label</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption> */}
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="carousal3"
          src="New-OPPO-And-VIVO-Smartphones-VIVO-Smartwatch-Coming-Soon_2_728x438.jpg"
          alt="Third slide"
        />
{/* 
        <Carousel.Caption>
          <h3>Third slide label</h3>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption> */}
      </Carousel.Item>
    </Carousel>
  );
}

export default UncontrolledExample;