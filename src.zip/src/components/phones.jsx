import React, { Component } from 'react'

export default class Phones extends Component {
  render() {
    return (
      <div><h1>Phones</h1></div>
    )
  }
}
