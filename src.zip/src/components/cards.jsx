import React from 'react'
import { Button, Card, Col, Container, Row } from 'react-bootstrap'
import "./navbar.css"
function CardsBS() {
    return (
        <Container>
            <Row >
            <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='cardsimages/redmi-note-11.png' />
                        <Card.Body>
                            <Card.Title className='text'>Redmi Note 11</Card.Title>
                            <Card.Subtitle  className='text'>PKR 43,000/-</Card.Subtitle>
                            <br/>
                            <div className='d-grid'>
                                <Button variant='light'>Add to cart</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='cardsimages/redmi10.png' />
                        <Card.Body>
                            <Card.Title className='text'>Redmi 10</Card.Title>
                            <Card.Subtitle  className='text'>PKR 30,000/-</Card.Subtitle>
                            <br/>
                            <div className='d-grid'>
                                <Button variant='light'>Add to cart</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='cardsimages/redmi10c.png' />
                        <Card.Body>
                            <Card.Title className='text'>Redmi 10C</Card.Title>
                            <Card.Subtitle  className='text'>PKR 32,000/-</Card.Subtitle>
                            <br/>
                            <div className='d-grid'>
                                <Button variant='light'>Add to cart</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
<br/><br/><br/>
            <Row >
            <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='cardsimages/Sam_a32.png' />
                        <Card.Body>
                            <Card.Title className='text'>Samsung A32</Card.Title>
                            <Card.Subtitle  className='text'>PKR 50,000/-</Card.Subtitle>
                            <br/>
                            <div className='d-grid'>
                                <Button variant='light'>Add to cart</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='cardsimages/sam_m33.png' />
                        <Card.Body>
                            <Card.Title className='text'>Samsung M33</Card.Title>
                            <Card.Subtitle  className='text'>PKR 35,000/-</Card.Subtitle>
                            <br/>
                            <div className='d-grid'>
                                <Button variant='light'>Add to cart</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='cardsimages/SamsungNote10.png' />
                        <Card.Body>
                            <Card.Title className='text'>Samsung Note 10</Card.Title>
                            <Card.Subtitle  className='text'>PKR 90,000/-</Card.Subtitle>
                            <br/>
                            <div className='d-grid'>
                                <Button variant='light'>Add to cart</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>


            <br/><br/><br/>

            <Row >
            <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='cardsimages/SamsungS21.png' />
                        <Card.Body>
                            <Card.Title className='text'>Samsung S21</Card.Title>
                            <Card.Subtitle  className='text'>PKR 162,000/-</Card.Subtitle>
                            <br/>
                            <div className='d-grid'>
                                <Button variant='light'>Add to cart</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='cardsimages/SamsungZFold.png' />
                        <Card.Body>
                            <Card.Title className='text'>Samsung Z Fold 4</Card.Title>
                            <Card.Subtitle  className='text'>PKR 430,000/-</Card.Subtitle>
                            <br/>
                            <div className='d-grid'>
                                <Button variant='light'>Add to cart</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='cardsimages/Xiaomi-Redmi-7.png' />
                        <Card.Body>
                            <Card.Title className='text'>Redmi 7</Card.Title>
                            <Card.Subtitle  className='text'>PKR 20,000/-</Card.Subtitle>
                            <br/>
                            <div className='d-grid'>
                                <Button variant='light'>Add to cart</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
        
    )
}

export default CardsBS