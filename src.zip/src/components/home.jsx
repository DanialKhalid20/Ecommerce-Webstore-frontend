import React, { Component } from 'react'
import ColorSchemesExample from './navbar'
import UncontrolledExample from './carousal'
import { Route,Routes } from 'react-router-dom'

import Contactus from './contactus'
import Aboutus from './aboutus'
import  Login from './login'
import CardsBS from './cards'
export default class Home extends Component {
  render() {
    return (
        <div>
        
           <UncontrolledExample/> 
           <br/><br/><br/><br/><br/>
           <CardsBS/>
        {/* <ColorSchemesExample/>
        <UncontrolledExample/>

        
        <div className="Container">
        <Routes>
        <Route path="/" element={<home/>}></Route>
        <Route path="/Menu" element={<menu/>}></Route>
        <Route path="/Contactus" element={<contactus/>}></Route>
        <Route path="/Aboutus" element={<aboutus/>}></Route>
        <Route path="/Login" element={<login/>}></Route>
        


        </Routes> 
       </div>*/}

       </div>
    )
  }
}
