import React, { useState } from "react";
import './navbar.css';
import Login1 from "./login1";
import Register  from "./register";

function Login() {

  
    return (
      <div className="App1">
        {
        //   <Login1/>
          <Register/>
        }
      </div>
    );
  }
  
  export default Login;