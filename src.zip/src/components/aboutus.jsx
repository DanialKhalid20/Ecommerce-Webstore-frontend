import React, { Component } from 'react';

import './aboutus.css';
import { Button, Card, Col, Container, Row } from 'react-bootstrap'

export default class Aboutus extends Component {
  render() {
    return (
       
      

        <Container>
        <div class ="About">
            <h2>Who are we?</h2>
        
        <p>We started our physical shop back in 1990's. As technology has advanced with passage of time, we strongly feel to connect with our customers online.<br/>We are here 
        to provide you our premium products in market competitive price. Feel free to order now before it's too late. Cash on delivery available.
       </p>
       </div>
        <Row >
        <h2 class ="About">Our Family</h2>
            <Col md={4}>
                    <Card bg='black'>
                    <Card.Img src='aboutus/owner.png' />
                        <Card.Body>
                            <Card.Title className='text'>Danial Khalid</Card.Title>
                            <Card.Subtitle  className='text'>Owner</Card.Subtitle>
                            <br/>
                            <Card.Text className='text'>Danial@gmail.com</Card.Text>
                          
                            <div className='d-grid'>
                                <Button variant='light'>Contact Now</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='aboutus/worker1.png' />
                        <Card.Body>
                            <Card.Title className='text'>Ali Ahmad</Card.Title>
                            <Card.Subtitle  className='text'>Worker 1</Card.Subtitle>
                            <br/>
                          
                            <Card.Text className='text'>Ali@gmail.com</Card.Text>
                          
                            <div className='d-grid'>
                                <Button variant='light'>Contact Now</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card bg='black'>
                        <Card.Img src='aboutus/worker2.png' />
                        <Card.Body>
                            <Card.Title className='text'>Adil khan</Card.Title>
                            <Card.Subtitle  className='text'>Worker 2</Card.Subtitle>
                                <br/>
                            <Card.Text className='text'>Adil@gmail.com</Card.Text>
                          
                            <div className='d-grid'>
                                <Button variant='light'>Contact Now</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>





        </Container>



        
    )
  }
}