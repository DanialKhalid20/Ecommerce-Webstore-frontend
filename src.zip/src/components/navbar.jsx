import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import './navbar.css';
import Home from './home';

import Login from './login';
import Contactus from './contactus';
import Aboutus from './aboutus';
import{Link} from "react-router-dom";
import { Routes,Route } from 'react-router-dom';
import { Row } from 'react-bootstrap';

function ColorSchemesExample() {
  return (
    <>
    <nav class="navbar navbar-expand-sm bg-light justify-content-center">
      <Navbar variant="dark" bg="dark">
      <Container className='mobbanner'>
        
        <Navbar.Brand href="#">The Mobile Shop</Navbar.Brand>
            </Container>
            
        
    </Navbar>
            
    </nav>
    <br/>
      <Navbar bg="dark" variant="dark">
        <Container>

          
          <Nav className="abc">
            <Nav.Link as={Link} to='/'>Home</Nav.Link>
            
            <Nav.Link as={Link} to='/cart'>Cart</Nav.Link>
            <Nav.Link as={Link} to='/contactus'>Contact Us</Nav.Link>
            <Nav.Link as={Link} to='/aboutus'>About Us</Nav.Link>
            <Nav.Link as={Link} to='/login'>Login</Nav.Link>
            
          

          </Nav>
        </Container>
      </Navbar>
    <br/>


    {/* <Home/>
    <Menu/>
    <Contactus/>
    <Aboutus/>
   <Login/> */}
        </>
        
  );
}

export default ColorSchemesExample;