import logo from './logo.svg';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Home from './components/home';

import ColorSchemesExample from './components/navbar';
import UncontrolledExample from './components/carousal';
import { Route,Routes } from 'react-router-dom';
import Contactus from './components/contactus';
import Aboutus from './components/aboutus';
import Login from './components/login';
import Cart from './components/cart';
import Contactform from './components/contactus';
function App() {
  return (
    <div className="App">
     <ColorSchemesExample/>
      
    <Routes>
<Route path='/' element={<Home/>}></Route>
<Route path='/cart' element={<Cart/>}></Route>
<Route path='/contactus' element={<Contactform/>}></Route>
<Route path='/aboutus' element={<Aboutus/>}></Route>
<Route path='/login' element={<Login/>}></Route>



    </Routes>
    
    
    </div>
  );
}

export default App;
